# Kasir Warung Kopi Aceh (Android)

Aplikasi kasir Android sederhana yang berjalan offline. Antarmuka dibuat dengan HTML/CSS/JavaScript lokal dan dibuka di Android WebView.

## Fitur
- Menu awal contoh khas warung kopi Aceh; nama dan harga dapat diubah.
- Keranjang, jumlah item, jenis pesanan (makan di tempat/bungkus).
- Pembayaran tunai dan hitung kembalian.
- Riwayat transaksi, omzet harian, jumlah transaksi, menu terlaris.
- Ekspor laporan ke CSV.
- Data disimpan lokal di perangkat menggunakan `localStorage`; tidak ada akun/server/sinkronisasi cloud.

## Persyaratan
- Android Studio versi stabil terbaru.
- Android SDK Platform 35 dan JDK yang disarankan oleh Android Studio (JDK 17 untuk konfigurasi ini).
- Internet hanya diperlukan untuk mengunduh Gradle/Android Gradle Plugin saat build pertama.

## Cara membuka dan build APK
1. Unduh dan ekstrak `KasirWarungKopiAceh-source.zip`.
2. Buka Android Studio → **Open** → pilih folder `KasirWarungKopiAceh` (folder yang berisi `settings.gradle.kts`).
3. Tunggu Gradle Sync selesai. Jika diminta, izinkan Android Studio mengunduh Android SDK Platform 35 dan komponen build.
4. Untuk mencoba di ponsel: aktifkan Developer options dan USB debugging, sambungkan ponsel, lalu tekan **Run ▶**.
5. Untuk membuat APK: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Setelah build berhasil, klik **locate** pada notifikasi. Biasanya APK berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP dan buka file tersebut untuk memasang. Android mungkin meminta izin memasang aplikasi dari sumber itu. Izinkan hanya jika Anda memang membuat/memercayai file APK tersebut.

## Penting
- Arsip ini berisi **source code proyek**, bukan APK yang sudah dikompilasi. APK perlu dibuat melalui Android Studio mengikuti langkah di atas.
- Untuk rilis publik, gunakan signing key milik sendiri dan jangan membagikannya.
- Data disimpan hanya pada perangkat. Menghapus data aplikasi/browser atau mengganti perangkat bisa menghilangkan riwayat; ekspor CSV secara berkala.
- Aplikasi belum memiliki backup otomatis, akun kasir, sinkronisasi antarperangkat, atau cetak struk langsung ke printer Bluetooth.
- Harga menu bawaan hanya contoh. Sesuaikan dengan harga warung Anda.


## Build APK hanya dengan HP (GitHub Actions)
Workflow cloud build disertakan di `.github/workflows/build-apk.yml`.

1. Di browser HP, masuk ke https://github.com dan buat akun/masuk.
2. Buat repository baru bernama `KasirWarungKopiAceh`. Untuk cara paling sederhana, pilih **Public** (source code dapat dilihat orang lain; jangan unggah rahasia/data pribadi).
3. Unggah semua isi folder proyek ini ke repository, termasuk folder tersembunyi `.github/workflows/build-apk.yml`. Pastikan `settings.gradle.kts` berada di root repository.
4. Buka tab **Actions** pada repository. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
5. Pilih workflow **Build Kasir Warung Kopi Aceh APK**, lalu tekan **Run workflow**. Jika tidak muncul, periksa bahwa `.github/workflows/build-apk.yml` sudah masuk ke branch `main`.
6. Tunggu sampai run berstatus hijau/sukses. Buka run tersebut, cari bagian **Artifacts**, lalu unduh `KasirWarungKopiAceh-debug-apk`.
7. Ekstrak ZIP artifact yang diunduh; di dalamnya ada `app-debug.apk`. Ketuk APK untuk memasang. Android mungkin meminta izin instalasi dari browser/file manager.

Catatan: build dijalankan oleh komputer cloud GitHub, bukan HP. GitHub Actions memiliki batas penggunaan sesuai jenis akun/repository. Jangan pernah membagikan password atau token GitHub. APK debug cocok untuk uji coba; untuk distribusi luas gunakan proses signing rilis yang dikelola dengan aman.
